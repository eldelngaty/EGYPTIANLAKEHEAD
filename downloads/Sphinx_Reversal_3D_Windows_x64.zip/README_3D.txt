SPHINX REVERSAL - TRUE 3D EDITION
Run SphinxReversal3D.exe. Enter closes the guide. WASD move, Shift sprint, hold right mouse and drag to orbit, C changes zoom, R reversal, E interact.
Modeled campus inspired by Lakehead references; not a surveyed digital twin. Full original scarab/key/map/rescue mission preserved.
