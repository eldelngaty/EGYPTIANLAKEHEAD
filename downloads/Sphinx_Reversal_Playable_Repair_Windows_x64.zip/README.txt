SPHINX REVERSAL — LAKEHEAD RESCUE / PLAYABILITY REPAIR RC1

Run SphinxReversal.exe. All game data is embedded; Godot installation and Internet access are not needed.
Right-drag / arrows: look. Click hotspots or press E when highlighted. R: reverse. Use the destination buttons to travel. M: discovered map. At the shrine: click symbols or type 3,2,1. ENTER / Play Again: restart.

Built with official Godot 4.7.2 Windows x64 release template. PE export and embedded game-data tests pass; native Windows execution was not available in the Linux validation environment.
