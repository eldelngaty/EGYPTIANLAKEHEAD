SPHINX REVERSAL - THIRD-PERSON ADVENTURE

Run SphinxReversalAdventure.exe. All assets are included.
WASD move, Shift run, mouse look, mouse wheel zoom, E interact, R reversal, M mission map, ESC pause/settings.
Follow the yellow marker. Altar: 3, 2, 1. Enter restarts after victory.

See README.md for validation, image attribution and known limits. Windows EXE is unsigned; no native Windows execution was available during Linux validation.
